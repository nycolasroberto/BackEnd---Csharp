using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GameCatalog.Models
{
    
    public class Game
    {
      
        public int Id { get; set; }

       
        [Required(ErrorMessage = "O nome do jogo é obrigatório")]
        [StringLength(200, ErrorMessage = "O nome deve ter no máximo 200 caracteres")]
        public string Nome { get; set; } = string.Empty;

       
        [StringLength(1000, ErrorMessage = "A descrição deve ter no máximo 1000 caracteres")]
        public string? Descricao { get; set; }

       
        [Required(ErrorMessage = "A data de lançamento é obrigatória")]
        [DataType(DataType.Date)]
        public DateTime DataLancamento { get; set; }

       
        [Required(ErrorMessage = "O preço é obrigatório")]
        [Range(0, 999.99, ErrorMessage = "O preço deve estar entre 0 e 999,99")]
        [Column(TypeName = "decimal(10,2)")]
        public decimal Preco { get; set; }

       
        [Required(ErrorMessage = "O desenvolvedor é obrigatório")]
        [StringLength(150, ErrorMessage = "O nome do desenvolvedor deve ter no máximo 150 caracteres")]
        public string Desenvolvedor { get; set; } = string.Empty;

       
        [Required(ErrorMessage = "A categoria é obrigatória")]
        public int CategoriaId { get; set; }

       
        public virtual Category? Categoria { get; set; }
    }
}